from django.contrib import admin

from .models import Student_name

admin.site.register(Student_name)
